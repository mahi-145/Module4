package com.cg.ui;

import java.util.Scanner;

import com.cg.dto.*;
import com.cg.service.*;

public class AuthorClient
{
	public static void main(String[] args)
	{

		AuthorService aSer=new AuthorServiceImpl();
		Scanner sc=new Scanner(System.in);
		Author auth= new Author();
		int c;
		do
		{
			System.out.println("1.Add Author");
			System.out.println("2.Update Author");
			System.out.println("3.Search Author");
			System.out.println("4.Delete Author");
			System.out.println("5.Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter First name of Author");
				String fname=sc.next();
				System.out.println("Enter Middle name of Author");
				String mname=sc.next();
				System.out.println("Enter Last name of Author");
				String lname=sc.next();
				System.out.println("Enter phone number of Author");
				long authPh=sc.nextLong();
				
				auth.setfName(fname);
				auth.setmName(mname);
				auth.setlName(lname);
				auth.setPhnNo(authPh);
				
				aSer.addAuthor(auth);
				System.out.println("Author is inserted");	
				break;
			case 2:
				System.out.println("Enter id to update  the Author");
				int autherid=sc.nextInt();
				auth=aSer.searchAuthor(autherid);
				System.out.println("Enter First name of Author");
					String ftname=sc.next();
					System.out.println("Enter Middle name of Author");
					String mdname=sc.next();
					System.out.println("Enter Last name of Author");
					String ltname=sc.next();
					System.out.println("Enter phone number of Author");
					long phone=sc.nextLong();
					
					auth.setfName(ftname);
					auth.setmName(mdname);
					auth.setlName(ltname);
					auth.setPhnNo(phone);
					
					aSer.updateAuthor(auth);
					System.out.println("Author details are Updated");	
				break;
			case 3:System.out.println("Enter id to Search the Author");
					int authid=sc.nextInt();
					auth=aSer.searchAuthor(authid);
					System.out.println(auth);
				break;
			case 4:System.out.println("Enter id to delete the Author");
					int aid=sc.nextInt();
					auth=aSer.searchAuthor(aid);	
					aSer.deleteAuthor(auth);
					System.out.println("Author details deleted");
				break;
			default: System.exit(0);
			
			}
		}while(true);
	}	
}
