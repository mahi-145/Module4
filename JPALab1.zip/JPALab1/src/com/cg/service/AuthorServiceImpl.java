package com.cg.service;

import com.cg.dao.*;
import com.cg.dto.Author;

public class AuthorServiceImpl implements AuthorService
{
AuthorDao adao=new AuthorDaoImpl();
	@Override
	public void addAuthor(Author auth) 
	{
		adao.addAuthor(auth);
	}

	@Override
	public void updateAuthor(Author auth)
	{
		adao.updateAuthor(auth);
		
	}

	@Override
	public void deleteAuthor(Author auth) 
	{
		adao.deleteAuthor(auth);
		
	}

	@Override
	public Author searchAuthor(int authId) 
	{
		return adao.searchAuthor(authId);
	}

}
