package com.cg.dto;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="author")
public class Author
{
	@Id
	@SequenceGenerator(name="authSeq",allocationSize=1,sequenceName="auth_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="authSeq")
	private int authorId;
	@Column(name="firstname")
	private String fName;
	@Column(name="middlename")
	private String mName;
	@Column(name="lastname")
	private String lName;
	@Column(name="phoneNo")
	private long phnNo;
	
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public long getPhnNo() {
		return phnNo;
	}
	public void setPhnNo(long phnNo) {
		this.phnNo = phnNo;
	}
	public Author(int authorId, String fName, String mName, String lName, long phnNo) {
		super();
		this.authorId = authorId;
		this.fName = fName;
		this.mName = mName;
		this.lName = lName;
		this.phnNo = phnNo;
	}
	public Author() {
		super();
		
	}
	@Override
	public String toString() {
		return "Author [authorId=" + authorId + ", fName=" + fName + ", mName="
				+ mName + ", lName=" + lName + ", phnNo=" + phnNo + "]";
	}
	
}
