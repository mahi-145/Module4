package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import com.cg.dto.Mobile;
@Repository("mobiledao")
public class MobileDaoImpl implements MobileDao
{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public void addMobileData(Mobile mob)
	{
		entityManager.persist(mob);
		entityManager.flush();
		
	}

	@Override
	public List<Mobile> showAllMobiles()
	{
		Query query1=entityManager.createQuery("FROM Mobile");          //write the entity name
		
		List<Mobile> myList= query1.getResultList();
		return myList;
	}

}
