package com.cg.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.dto.Mobile;


public interface MobileDao
{
	public void addMobileData(Mobile mob);
	public List<Mobile> showAllMobiles();
}
