package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.MobileDao;
import com.cg.dto.Mobile;
@Service("mobileservice")
@Transactional
public class MobileServiceImpl implements MobileService
{
	@Autowired
	MobileDao mobiledao;

	@Override
	public void addMobileData(Mobile mob) 
	{
		mobiledao.addMobileData(mob);

	}

	@Override
	public List<Mobile> showAllMobiles() {
		// TODO Auto-generated method stub
		return mobiledao.showAllMobiles();
	}

}
