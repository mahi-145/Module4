package com.cg.service;

import java.util.List;

import com.cg.dto.Mobile;

public interface MobileService
{
	public void addMobileData(Mobile mob);
	public List<Mobile> showAllMobiles();
}
