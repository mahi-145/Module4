package com.cg.ctrl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.Mobile;
import com.cg.service.MobileService;


@Controller
public class myController
{
	@Autowired
	MobileService mobileservice;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "home";	
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my")Mobile mob, Map<String,Object> model ) //map used to send data to addemployee.jsp
	{
		List<String> myCat=new ArrayList<>();
		myCat.add(" Android ");
		myCat.add(" IOS ");
		model.put("cat",myCat);
		
		return "addmobile";
	}
	
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public String insertEmployee(@ModelAttribute("my") Mobile mob)
	{
		//System.out.println(" Name is :"+emp.getEmpName());
		mobileservice.addMobileData(mob);
		
		return "success";
		
	}
	
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		List<Mobile> myAllData =mobileservice.showAllMobiles();
		
		return new ModelAndView("showall", "temp", myAllData);		//
	}

}
