package com.cg.trainee.dao;

import java.util.List;
import com.cg.trainee.dto.TraineeBean;

public interface TraineeDao 
{	

	int addTraineeData(TraineeBean train);
	void deleteTraineeData(int trainId);
	public List<TraineeBean> showAllTraineeBean();
	public List<TraineeBean> showOneTrainee(int trainId);
	public void updateTrainee(TraineeBean tb);
}
