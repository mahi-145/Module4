package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import com.cg.trainee.dto.TraineeBean;

@Repository("traineedao")
public class TraineeDaoImpl implements TraineeDao
{
	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public int addTraineeData(TraineeBean train) 
	{
		em.persist(train);
		em.flush();
		return train.getTrainId();
	}

	@Override
	public void deleteTraineeData(int trainId) 
	{
		Query qry=em.createQuery("Delete From TraineeBean Where trainId=:tId");
		qry.setParameter("tId", trainId);
		qry.executeUpdate();
	}

	@Override
	public List<TraineeBean> showAllTraineeBean() 
	{
		Query qry=em.createQuery("From TraineeBean");
		List<TraineeBean> myList=qry.getResultList();
		return myList;

	}

	@Override
	public List<TraineeBean> showOneTrainee(int TrainId) 
	{
		Query qry=em.createQuery("From TraineeBean Where trainId=:tId");
		qry.setParameter("tId", TrainId);
		List<TraineeBean> myList=qry.getResultList();
		return myList;
	}

	@Override
	public void updateTrainee(TraineeBean tb) 
	{
//		Query qry=em.createQuery("UPDATE TraineeBean SET trainName=:tName, trainDomain=:tDomain, trainLocation=:tLoc Where trainId=:tId");
//		qry.setParameter("tName", tb.getTrainName());
//		qry.setParameter("tDomain", tb.getTrainDomain());
//		qry.setParameter("tLoc", tb.getTrainLocation());
//		qry.setParameter("tId",tb.getTrainId());
//		qry.executeUpdate();
		em.merge(tb);
		
	}
	
	
	
}
