package com.cg.trainee.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.dto.TraineeBean;
import com.cg.trainee.service.TraineeService;


@Controller
public class MyController
{
	@Autowired
	TraineeService trainservice;
	
	@RequestMapping(value="all", method=RequestMethod.GET)
	public String getAll()
	{
		return "login";
	}
	
	@RequestMapping(value="home", method=RequestMethod.GET)
	public String inHome()
	{
		return "management";
	}
	
	@RequestMapping(value="add", method=RequestMethod.GET)
	public String add(@ModelAttribute("my") TraineeBean train, Map<String,Object> model)
	{
		List<String> myDom=new ArrayList<>();
		myDom.add("Java");
		myDom.add("VnV");
		myDom.add("dotNet");
		model.put("dom", myDom);
		return "add";
	}
	
	@RequestMapping(value="insertdata", method=RequestMethod.POST)
	public String insertData(@ModelAttribute("my") TraineeBean train)
	{
		int id=trainservice.addTraineeData(train);
		return "addsuccess";
	}
	
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String delete()
	{
		return "delete";
	}
	
	@RequestMapping(value="dodelete", method=RequestMethod.GET)
	public ModelAndView deleteTrainee(@RequestParam("tid") int id)
	{
//		trainservice.deleteTraineeData(id);
//		return "deletesuccess";
		
		List<TraineeBean> trainData=trainservice.showOneTrainee(id);
		return new ModelAndView("delete","temp",trainData);

	}
	@RequestMapping(value="dodelete2", method=RequestMethod.GET)
	public String deleteTrainee2(@RequestParam("tid") int id)
	{
		trainservice.deleteTraineeData(id);
		return "deletesuccess";

	}
	@RequestMapping(value="RetreiveAll", method=RequestMethod.GET)
	public ModelAndView showAll()
	{
		List<TraineeBean> trainData=trainservice.showAllTraineeBean();
		return new ModelAndView("showall","temp",trainData);
	}
	
	@RequestMapping(value="Retrieve", method=RequestMethod.GET)
	public String show()
	{
		return "showOne";
	}
	
//	@RequestMapping(value="Retrieve", method=RequestMethod.GET)
//	public ModelAndView showOne(@RequestParam("tid") int id)
//	{
//		List<TraineeBean> trainData=trainservice.showOneTrainee(id);
//		return new ModelAndView("showone","temp",trainData);
//	}
	
	@RequestMapping(value="search", method=RequestMethod.POST)
	public ModelAndView showOneTrainee(@RequestParam("tid") int id)
	{
		List<TraineeBean> trainData=trainservice.showOneTrainee(id);
		return new ModelAndView("showOne","temp",trainData);
	}
	
	@RequestMapping(value="Modify", method=RequestMethod.GET)
	public String update()
	{
		return "modifytrainee";
	}
	
	@RequestMapping(value="domodify", method=RequestMethod.GET)
	public ModelAndView updateModify(@RequestParam("tid") int id,@ModelAttribute("my") TraineeBean tr)
	{
		System.out.println("123");
		
		List<TraineeBean>	 trainData=trainservice.showOneTrainee(id);
		//for (TraineeBean traineeBean : trainData) {
			//System.out.println(trainData);
//		}
		return new ModelAndView("modifytrainee","train",trainData);
	}
	
	@RequestMapping(value="doUpdate", method=RequestMethod.GET)
	public String doneUpdate(@ModelAttribute("my") TraineeBean tb)
	{
		System.out.println("456");
		//System.out.println(tb +" "+ id);
		trainservice.updateTrainee(tb);
		return "successUpdate";
	}
	
}
