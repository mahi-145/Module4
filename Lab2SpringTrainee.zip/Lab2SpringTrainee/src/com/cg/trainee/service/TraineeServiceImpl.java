package com.cg.trainee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.dao.TraineeDao;
import com.cg.trainee.dto.TraineeBean;

@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements TraineeService
{
	@Autowired
	TraineeDao traineedao;

	@Override
	public int addTraineeData(TraineeBean train) 
	{
		return traineedao.addTraineeData(train);
	}

	@Override
	public void deleteTraineeData(int trainId)
	{
		 traineedao.deleteTraineeData(trainId);
	}

	@Override
	public List<TraineeBean> showAllTraineeBean() 
	{
		return traineedao.showAllTraineeBean();
	}

	@Override
	public List<TraineeBean> showOneTrainee(int trainId) {
		// TODO Auto-generated method stub
		return traineedao.showOneTrainee(trainId);
	}

	@Override
	public void updateTrainee(TraineeBean tb) 
	{
		 traineedao.updateTrainee(tb);
		
	}
	
	
	
}
