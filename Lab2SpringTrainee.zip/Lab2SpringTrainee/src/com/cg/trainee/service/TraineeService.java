package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.dto.TraineeBean;

public interface TraineeService 
{
	
	int addTraineeData(TraineeBean train);
	void deleteTraineeData(int trainId);
	public List<TraineeBean> showAllTraineeBean();
	public List<TraineeBean> showOneTrainee(int trainId);
	public void updateTrainee(TraineeBean tb);
}
