package com.cg.trainee.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="traineeInformation")
public class TraineeBean 
{
	
	@Override
	public String toString() {
		return "TraineeBean [trainId=" + trainId + ", trainName=" + trainName
				+ ", trainLocation=" + trainLocation + ", trainDomain="
				+ trainDomain + "]";
	}

	@Id
	@SequenceGenerator(name="trainee_seq", sequenceName="train_seq_id", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="trainee_seq")
	@Column(name="train_id")
	private Integer trainId;
	
	@Column(name="train_Name")
	private String trainName;

	@Column(name="tarin_location")
	private String trainLocation;
	
	@Column(name="train_domain")
	private String trainDomain;

	public Integer getTrainId() {
		return trainId;
	}

	public void setTrainId(Integer trainId) {
		this.trainId = trainId;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public String getTrainLocation() {
		return trainLocation;
	}

	public void setTrainLocation(String trainLocation) {
		this.trainLocation = trainLocation;
	}

	public String getTrainDomain() {
		return trainDomain;
	}

	public void setTrainDomain(String trainDomain) {
		this.trainDomain = trainDomain;
	}
	
	
}
