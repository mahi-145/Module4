package com.cg.springmvcone.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.enterprise.inject.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcone.dto.Employee;
import com.cg.springmvcone.service.IEmployeeService;

@Controller
public class MyController 
{
	@Autowired
	IEmployeeService employeeservice;

	@RequestMapping(value="all", method=RequestMethod.GET)
	public String getAll() {
		return "home";
	}

	@RequestMapping(value="add", method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my") Employee emp, Map<String, Object>model) {

		List<String> myDeg = new ArrayList<>();

		myDeg.add("Software Engineer");
		myDeg.add("Senior Consultant");
		myDeg.add("Manager");

		model.put("deg", myDeg);

		return "addemployee";
	}

	@RequestMapping(value="insertdata", method=RequestMethod.POST)
	public String insertEmployee(@ModelAttribute("my") Employee emp) {

		//System.out.println("Name is " + emp.getEmpName());
		employeeservice.addEmployee(emp);
		return "success";
	}
	
	@RequestMapping(value="show",method=RequestMethod.GET)
	
	public ModelAndView showAllEmployee()
	{
		List<Employee> myAllData=employeeservice.showAllEmployee();
		
		return new ModelAndView("showAll","temp",myAllData);
		
	}
}
