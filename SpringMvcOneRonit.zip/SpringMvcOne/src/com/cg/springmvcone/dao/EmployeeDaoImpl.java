package com.cg.springmvcone.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcone.dto.Employee;

@Repository("employeedao")

public class EmployeeDaoImpl implements IEmployeeDao
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public void addEmployee(Employee emp) 
	{
		
		entitymanager.persist(emp);
		entitymanager.flush();
		
	}

	@Override
	public List<Employee> showAllEmployee() 
	{
		Query queryOne=entitymanager.createQuery("FROM Employee");
		List<Employee> myList=queryOne.getResultList();
		return myList;
	
	}

	@Override
	public void deleteEmployee(int empId) 
	{
		
		
	}

	@Override
	public void updateEmployee(Employee emp)
	{
		
		
	}

	@Override
	public Employee searchEmployee(int id)
	{
		
		return null;
	}

}
