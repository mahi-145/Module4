package com.cg.mcam.exception;

public class MediaException extends Exception
{

	public MediaException(String msg)
	{
		super(msg);
	}
}
