package com.cg.mcam.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;



public class DBUtil 
{

	static String dbunm=null;
	static String dbpwd=null;
	static String url=null;
	
	public static Connection getCon() throws SQLException, IOException 
	{
		 Connection con=null;
		
		Properties dbinfoProps=DBUtil.getProp();
		url=dbinfoProps.getProperty("dbUrl");
		dbunm=dbinfoProps.getProperty("dbUser");
		dbpwd=dbinfoProps.getProperty("dbPwd");
		
		
		if(con==null)
		{
			con=DriverManager.getConnection(url,dbunm,dbpwd);
		}
		return con;
	}

	public static Properties getProp() throws IOException
	{
		Properties props=null;
		FileReader fr=null;

			props=new Properties();

			fr=new FileReader("resources/dbinfo.properties");

			props.load(fr);
			
			return props;
		
	}
		

	
}
