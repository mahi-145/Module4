package com.cg.dto;

public class Employee 
{

	int employeeId;
	String employeeName;
	double salary;
	SBU businessUnit;
	int age;
	

	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public SBU getBusinessUnit() {
		return businessUnit;
	}


	public void setBusinessUnit(SBU businessUnit) {
		this.businessUnit = businessUnit;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}

	public void getSbuDetails() {
		// TODO Auto-generated method stub
		System.out.println("Employee Details");
		System.out.println("----------------------------");
		System.out.println("Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", salary=" + salary + ",]\n[ businessUnit="
				+ businessUnit.getSbuDetails() + ", age=" + age + "]");
		
	}

	

	
}
