package com.cg.dto;

import java.util.List;

public class Employee implements EmployeeDetails  {

	int empId;
	String empName;
	//Project proOne;
	//Project proTwo;
	List<Project> pro;
	
	

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public List<Project> getPro() {
		return pro;
	}

	public void setPro(List<Project> pro) {
		this.pro = pro;
	}

	@Override
	public void getAllEmployeeDetail()
	
	{
		System.out.println("Employee Id is: "+empId);
		System.out.println("Employee Name is: "+empName);
		for(Project project:pro)
		{
			System.out.println("Project Id is: "+project.getProjId());
			System.out.println("Project Name is: "+project.getProjName());
		}
		//System.out.println("Project Id is: "+proOne.getProjId());
		//System.out.println("Project Name is: "+proOne.getProjName());
		
		//System.out.println("Project Id is: "+proTwo.getProjId());
		//System.out.println("Project Name is: "+proTwo.getProjName());
		
		
	}
	
	
		/*public Project getProOne() {
				return proOne;
			}
			
			
			
			public void setProOne(Project proOne) {
				this.proOne = proOne;
			}
			
			
			
			public Project getProTwo() {
				return proTwo;
			}
			
			
			
			public void setProTwo(Project proTwo) {
				this.proTwo = proTwo;
			}
			*/
			
				
}







/*  <property name="proOne" ref="one"></property>
     <property name="proTwo" ref="two"></property>*/
