package com.cg.dto;

public class Employee implements EmployeeDetails  {

	int empId;
	String empName;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}



	@Override
	public void getAllEmployeeDetail()
	
	{
		System.out.println("Id is: "+empId);
		System.out.println("Name is: "+empName);
		
	}

	
}
