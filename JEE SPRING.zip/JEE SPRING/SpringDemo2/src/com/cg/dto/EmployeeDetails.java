package com.cg.dto;

public interface EmployeeDetails
{
	public void getAllEmployeeDetail();

}
