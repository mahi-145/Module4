package com.cg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.EmployeeDetails;

public class MyTest 
{

	public static void main(String[] args)
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		
		EmployeeDetails e=(EmployeeDetails)app.getBean("emp");
		e.getAllEmployeeDetail();

	}

}



//three ways to write constructor injection in spring.xml
/* <constructor-arg index="0" value="142831"></constructor-arg>
<constructor-arg index="1" value="Shweta Wadhwani"></constructor-arg>



<constructor-arg type="int" value="142831"></constructor-arg>
<constructor-arg type="String" value="Shweta Wadhwani"></constructor-arg>


<constructor-arg name="empId" value="142831"></constructor-arg>
<constructor-arg  name="empName" value="Shweta Wadhwani"></constructor-arg>

*/