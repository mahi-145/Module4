package com.cg.dto;

import java.util.List;

public class SBU implements Details
{
	String sbuId;
	String sbuName;
	String sbuHead;
	List<Employee> empList;

	public String getSbuId() {
		return sbuId;
	}


	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}


	public String getSbuName() {
		return sbuName;
	}


	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}


	public String getSbuHead() {
		return sbuHead;
	}


	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	

	public List<Employee> getEmpList() {
		return empList;
	}


	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	
	public void getSbuDetails() 
	{
		System.out.println("SBU DETAILS");
		System.out.println("-------------------------------");
		System.out.println("SBU [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead="
				+ sbuHead + "]");	
		System.out.println("-------------------------------");
		for(Employee emp:empList)
		{
			System.out.println("Employee [employeeId=" + emp.getEmployeeId() + ", employeeName="
					+ emp.getEmployeeName() + ", salary=" + emp.getSalary() +  "]");
		}
	}


	

}
