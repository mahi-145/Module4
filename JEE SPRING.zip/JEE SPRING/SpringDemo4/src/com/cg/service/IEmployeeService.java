package com.cg.service;

public interface IEmployeeService
{

	public void getData();
	
}
