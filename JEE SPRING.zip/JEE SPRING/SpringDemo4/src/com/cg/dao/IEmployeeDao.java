package com.cg.dao;

public interface IEmployeeDao
{
	public void getDetails();
}
