package com.cg.dto;

public class Circle implements Shape
{

	@Override
	public void getShape() 
	{
		System.out.println(".........In circle");
		
	}

	
}
