package com.cg.dto;

public class Employee 
{

	int empId;
	String empName;
	
	
	public int getEmpId() 
	{
		return empId;
	}


	public void setEmpId(int empId) 
	{
		this.empId = empId;
	}


	public String getEmpName() 
	{
		return empName;
	}


	public void setEmpName(String empName) 
	{
		this.empName = empName;
	}


	public void getAllEmployee()
	{
		System.out.println(" Employee Id is "+ empId+ " Employee name is: "+empName);
	}
//	@Override
//	public void getAllDetails() 
//	{
//		System.out.println("Emp Name: Ronit Nagwekar");
//		System.out.println("Emp_Id: 142282");
//		
//	}
	
}
