package com.cg.dto;

public interface Details 
{
 public void getAllDetails();
}
