package com.cg.dao;

import org.springframework.stereotype.Component;

@Component("employeedao")
public class EmployeeDaoImpl implements EmployeeDao 
{

	@Override
	public void getDetails() 
	{
		
		
	}

}
