package com.cg.dao;

public interface EmployeeDao 
{
	public void getDetails();
}
