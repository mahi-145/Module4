package com.cg.dto;

import org.springframework.stereotype.Component;

@Component("emp")
public class Employee 
{
	
	
	public void getDetails()
	{
		
	}
}
