package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dto.Mobile;

public interface IMobileService
{
	
	public List<Mobile> showAllMobile();
	public void deleteMob(int mobId);
	public void updateMobile(Mobile mob);
}
