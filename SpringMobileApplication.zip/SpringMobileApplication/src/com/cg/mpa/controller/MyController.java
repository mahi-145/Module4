package com.cg.mpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.service.IMobileService;


@Controller
public class MyController 
{
	@Autowired
	IMobileService mobileservice;
	
	@RequestMapping(value="showall", method=RequestMethod.GET)
	public ModelAndView allMobileData(@ModelAttribute("my") Mobile mob)
	{
		List<Mobile> mobData = mobileservice.showAllMobile();
		return new ModelAndView("show","temp",mobData);
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String mobileDelete(@RequestParam("id") int mobId){
		System.out.println(mobId);
		mobileservice.deleteMob(mobId);
		return "redirect:/showall";
		
		
	}
	
	
	
	
}
