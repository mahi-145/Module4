package com.cg.mpa.dao;

import java.util.List;

import com.cg.mpa.dto.Mobile;

public interface IMobileDao 
{
	public List<Mobile> showAllMobile();
	public void deleteMob(int mobId);
	public void updateMobile(Mobile mob);

}
