package com.cg.mpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.mpa.dto.Mobile;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao
{
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Mobile> showAllMobile() 
	{
		Query queryone=entityManager.createQuery("FROM Mobile");
		List<Mobile> allData=queryone.getResultList();
		return allData;
	}

	@Override
	public void deleteMob(int mobId) {
		Query querytwo = entityManager.createQuery("DELETE FROM Mobile WHERE mobId=:mId");
		querytwo.setParameter("mId",mobId);
		querytwo.executeUpdate();
		
	}

	@Override
	public void updateMobile(Mobile mob) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
