package com.cg.labtwo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.labtwo.dao.ITraineeDao;
import com.cg.labtwo.dto.Trainee;
@Service("traineeservice")
@Transactional()
public class TraineeServiceImpl implements ITraineeService
{
	@Autowired
	ITraineeDao traineedao;
	@Override
	public int addTraineeData(Trainee tra) 
	{
		return traineedao.addTraineeData(tra);
	}
	@Override
	public List<Trainee> searchTrainee(int id)
	{
		return traineedao.searchTrainee(id);
	}
	@Override
	public void deleteTrainee(int traineeId) {
		traineedao.deleteTrainee(traineeId);
		
	}
	@Override
	public List<Trainee> retrieveTrainee(int trnid)
	{
		return traineedao.retrieveTrainee(trnid);
	}
	@Override
	public List<Trainee> retrieveAllTrainee() 
	{
		return traineedao.retrieveAllTrainee();
	}

}
