package com.cg.labtwo.service;

import java.util.List;

import com.cg.labtwo.dto.Trainee;

public interface ITraineeService 
{
	public int addTraineeData(Trainee tra);
	public List<Trainee> searchTrainee(int id);
	public void deleteTrainee(int traineeId);
	public List<Trainee> retrieveTrainee(int trnid);
	public List<Trainee> retrieveAllTrainee();
}
