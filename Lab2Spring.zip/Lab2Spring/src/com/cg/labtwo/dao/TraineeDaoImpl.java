package com.cg.labtwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.labtwo.dto.Trainee;

@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public int addTraineeData(Trainee tra) 
	{
		entitymanager.persist(tra);
		entitymanager.flush();
		return tra.getTraineeId();
	}
	@Override
	public List<Trainee> searchTrainee(int id)
	{
		Query queryone = entitymanager.createQuery("SELECT t FROM Trainee t WHERE traineeId=:tid");
		queryone.setParameter("tid", id);
		return queryone.getResultList();
	}
	@Override
	public void deleteTrainee(int traineeId) 
	{
		Query querytwo=entitymanager.createQuery("DELETE FROM Trainee WHERE traineeId=:id");
		querytwo.setParameter("id", traineeId);
		querytwo.executeUpdate();
		
	}
	@Override
	public List<Trainee> retrieveTrainee(int trnid) 
	{
		Query queryone = entitymanager.createQuery("SELECT t FROM Trainee t WHERE traineeId=:tid");
		queryone.setParameter("tid", trnid);
		return queryone.getResultList();
	}
	@Override
	public List<Trainee> retrieveAllTrainee() 
	{
		Query querythree = entitymanager.createQuery("FROM Trainee");
		
		return querythree.getResultList();
	}
	@Override
	public void updateTrainee(Trainee tra)
	{
		Query queryfour = entitymanager.createQuery("UPDATE Trainee SET traineeName=:tname,traineeLocation=:tloc,traineeDomain=:tdomain WHERE traineeId=:tid");
		queryfour.setParameter("tid",tra.getTraineeId());
		queryfour.setParameter("tname",tra.getTraineeName());
		queryfour.setParameter("tloc",tra.getTraineeLocation());
		queryfour.setParameter("tdomain",tra.getTraineeDomain());
		queryfour.executeUpdate();
		
	}

}
