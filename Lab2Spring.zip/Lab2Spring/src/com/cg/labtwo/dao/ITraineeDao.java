package com.cg.labtwo.dao;

import java.util.List;

import com.cg.labtwo.dto.Trainee;

public interface ITraineeDao 
{
	public int addTraineeData(Trainee tra);
	public List<Trainee> searchTrainee(int id);
	public void deleteTrainee(int traineeId);
	public List<Trainee> retrieveTrainee(int trnid);
	public List<Trainee> retrieveAllTrainee();
}
