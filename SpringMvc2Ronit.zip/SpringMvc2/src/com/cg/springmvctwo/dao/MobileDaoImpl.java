package com.cg.springmvctwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvctwo.dto.Mobile;

@Repository
public class MobileDaoImpl implements MobileDao {

	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public List<Mobile> showAllMobile() 
	{
		Query queryOne=entitymanager.createQuery("FROM Mobile");
		List<Mobile> allData=queryOne.getResultList();
		return allData;
	}

	@Override
	public void deleteMobile(int mobId) 
	{
		
		Query querytwo=entitymanager.createQuery("DELETE FROM Mobile WHERE mobId=:id");
		querytwo.setParameter("id", mobId);
		querytwo.executeUpdate();
	}

	@Override
	public void updateMobile(Mobile mob) 
	{
		

	}

}
