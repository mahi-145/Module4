package com.cg.media.bean;

import java.sql.Date;

public class Composer_Master 

{
	private int composer_Id;
	private String composer_Name;
	private String composer_Born_Date;
	private Date composer_Died_Date;
	private String composer_Caeipi_Number;
	private int Created_by;
	private Date Created_on;
	private int Updated_by;
	private Date Updadted_on;
	
	public int getComposer_Id() {
		return composer_Id;
	}
	public void setComposer_Id(int composer_Id) {
		this.composer_Id = composer_Id;
	}
	public String getComposer_Name() {
		return composer_Name;
	}
	public void setComposer_Name(String composer_Name) {
		this.composer_Name = composer_Name;
	}
	public String getComposer_Born_Date() {
		return composer_Born_Date;
	}
	public void setComposer_Born_Date(String composer_Born_Date) {
		this.composer_Born_Date = composer_Born_Date;
	}
	public Date getComposer_Died_Date() {
		return composer_Died_Date;
	}
	public void setComposer_Died_Date(Date composer_Died_Date) {
		this.composer_Died_Date = composer_Died_Date;
	}
	public String getComposer_Caeipi_Number() {
		return composer_Caeipi_Number;
	}
	public void setComposer_Caeipi_Number(String composer_Caeipi_Number) {
		this.composer_Caeipi_Number = composer_Caeipi_Number;
	}
	public int getCreated_by() {
		return Created_by;
	}
	public void setCreated_by(int created_by) {
		Created_by = created_by;
	}
	public Date getCreated_on() {
		return Created_on;
	}
	public void setCreated_on(Date created_on) {
		Created_on = created_on;
	}
	public int getUpdated_by() {
		return Updated_by;
	}
	public void setUpdated_by(int updated_by) {
		Updated_by = updated_by;
	}
	public Date getUpdadted_on() {
		return Updadted_on;
	}
	public void setUpdadted_on(Date updadted_on) {
		Updadted_on = updadted_on;
	}
	public Composer_Master() {
		super();
		
	}
	public Composer_Master(int composer_Id, String composer_Name,
			String composer_Born_Date, Date composer_Died_Date,
			String composer_Caeipi_Number, int created_by, Date created_on,
			int updated_by, Date updadted_on) {
		super();
		this.composer_Id = composer_Id;
		this.composer_Name = composer_Name;
		this.composer_Born_Date = composer_Born_Date;
		this.composer_Died_Date = composer_Died_Date;
		this.composer_Caeipi_Number = composer_Caeipi_Number;
		Created_by = created_by;
		Created_on = created_on;
		Updated_by = updated_by;
		Updadted_on = updadted_on;
	}
	@Override
	public String toString() {
		return "Composer_Master [composer_Id=" + composer_Id
				+ ", composer_Name=" + composer_Name + ", composer_Born_Date="
				+ composer_Born_Date + ", composer_Died_Date="
				+ composer_Died_Date + ", composer_Caeipi_Number="
				+ composer_Caeipi_Number + ", Created_by=" + Created_by
				+ ", Created_on=" + Created_on + ", Updated_by=" + Updated_by
				+ ", Updadted_on=" + Updadted_on + "]";
	}

	





}
