package com.cg.media.bean;

import java.sql.Date;

public class Artist_Master
{

	private int artist_Id;
	private String artist_Name;
	private String artist_Type;
	private String artist_Born_Date;
	private Date artist_Died_Date;
	private int created_By;
	private Date created_On;
	private int updated_By;
	private Date updated_On;
	
	public int getArtist_Id() {
		return artist_Id;
	}
	public void setArtist_Id(int artist_Id) {
		this.artist_Id = artist_Id;
	}
	public String getArtist_Name() {
		return artist_Name;
	}
	public void setArtist_Name(String artist_Name) {
		this.artist_Name = artist_Name;
	}
	public String getArtist_Type() {
		return artist_Type;
	}
	public void setArtist_Type(String artist_Type) {
		this.artist_Type = artist_Type;
	}
	public String getArtist_Born_Date() {
		return artist_Born_Date;
	}
	public void setArtist_Born_Date(String artist_Born_Date) {
		this.artist_Born_Date = artist_Born_Date;
	}
	public Date getArtist_Died_Date() {
		return artist_Died_Date;
	}
	public void setArtist_Died_Date(Date artist_Died_Date) {
		this.artist_Died_Date = artist_Died_Date;
	}
	public int getCreated_By() {
		return created_By;
	}
	public void setCreated_By(int created_By) {
		this.created_By = created_By;
	}
	public Date getCreated_On() {
		return created_On;
	}
	public void setCreated_On(Date created_On) {
		this.created_On = created_On;
	}
	public int getUpdated_By() {
		return updated_By;
	}
	public void setUpdated_By(int updated_By) {
		this.updated_By = updated_By;
	}
	public Date getUpdated_On() {
		return updated_On;
	}
	public void setUpdated_On(Date updated_On) {
		this.updated_On = updated_On;
	}
	public Artist_Master() {
		super();
		
	}
	public Artist_Master(int artist_Id, String artist_Name, String artist_Type,
			String artist_Born_Date, Date artist_Died_Date, int created_By,
			Date created_On, int updated_By, Date updated_On) {
		super();
		this.artist_Id = artist_Id;
		this.artist_Name = artist_Name;
		this.artist_Type = artist_Type;
		this.artist_Born_Date = artist_Born_Date;
		this.artist_Died_Date = artist_Died_Date;
		this.created_By = created_By;
		this.created_On = created_On;
		this.updated_By = updated_By;
		this.updated_On = updated_On;
	}
	@Override
	public String toString() {
		return "Artist_Master [artist_Id=" + artist_Id + ", artist_Name="
				+ artist_Name + ", artist_Type=" + artist_Type
				+ ", artist_Born_Date=" + artist_Born_Date
				+ ", artist_Died_Date=" + artist_Died_Date + ", created_By="
				+ created_By + ", created_On=" + created_On + ", updated_By="
				+ updated_By + ", updated_On=" + updated_On + "]";
	}
	
	
	
	
}
