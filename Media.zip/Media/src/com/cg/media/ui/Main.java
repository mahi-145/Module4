package com.cg.media.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		System.out.println("Choose");
		System.out.println("\n \t 1) select on composer id ");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			
			switch(choice)
			{
			case 1:  
				System.out.println("Enter the composer id..");
				int compId=sc.nextInt();
				String selectQry="SELECT * from composer_master where composer_id=?";
				pst=con.prepareStatement(selectQry);
				pst.setInt(1, compId);
				rs=pst.executeQuery();
				rs.next();
				System.out.println(rs.getInt("composer_Id"));
				System.out.println(rs.getString("composer_Name"));
				System.out.println(rs.getString("composer_Born_Date"));
				System.out.println(rs.getDate("composer_Died_Date"));
				System.out.println(rs.getString("composer_Caeipi_Number"));
				System.out.println(rs.getInt("Created_by"));
				System.out.println(rs.getDate("Created_on"));
				System.out.println(rs.getInt("Updated_by"));
				System.out.println(rs.getDate("Updated_on"));
				break;
				
				default:
								System.out.println("Not a valid choice");
				
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}

}
