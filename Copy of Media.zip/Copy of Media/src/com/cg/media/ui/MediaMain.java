package com.cg.media.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.naming.spi.DirStateFactory.Result;

import com.cg.media.bean.Artist_Master;
import com.cg.media.bean.Composer_Master;
import com.cg.media.bean.Song_Master;
import com.cg.media.exception.MediaException;
import com.cg.media.service.MediaService;
import com.cg.media.service.MediaServiceImpl;



public class MediaMain
{
	static Scanner sc=null;
	static MediaService medSer=null;

	public static void main(String[] args) throws MediaException, SQLException
	{
		medSer= new MediaServiceImpl();
		sc=new Scanner(System.in);

		while(true)
		{

			System.out.println("*************WELCOME TO MEDIA COMPOSER AND ARTIST MANAGEMENT SYSTEM***********");
			System.out.println("Select the type of user you are :");
			System.out.println("\n1. Admin");
			System.out.println("\n2. User");

			int choice1=sc.nextInt();

			switch(choice1)
			{

			case 1:

				System.out.println("************************************************************");
				System.out.println("********************WELCOME ADMIN******************");
				System.out.println("************************************************************");
				System.out.println("Please enter your login credential");
				System.out.println("Enter Admin Id : ");
				int adminId=sc.nextInt();
				System.out.println("Enter Admin Password");
				String adminPwd=sc.next();
				if(medSer.validateAdminId(adminId))
				{
					if(medSer.validateAdminPwd(adminPwd))
					{
						System.out.println("Welcome you are logged in as Admin");
						System.out.println("Select the operation to perform");
						System.out.println(" \n \t 1: Add Composer \n  \t 2: Add artist \n \t 3: Find Composer \n  \t 4: Find Artist \n \t 5: Add Song   ");


						int choice=sc.nextInt();
						switch(choice)
						{

						case 1: AddComposer();
						break;

						case 2: AddArtist();
						break;

						case 3: 	
						System.out.println("Enter the Composer id: ");
						int compId=sc.nextInt();
						String selectQry="SELECT * from composer_master where composer_id=?";
						Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
						PreparedStatement pst=con.prepareStatement(selectQry);
						pst.setInt(1, compId);
						ResultSet rs=pst.executeQuery();
						rs.next();
						System.out.println("Composer ID: "+rs.getInt("composer_Id"));
						System.out.println("Composer Name: "+rs.getString("composer_Name"));
						System.out.println("Composer Birth Date: " +rs.getString("composer_Born_Date"));
						System.out.println("Composer Died Date: "+rs.getDate("composer_Died_Date"));
						System.out.println("Composer Caeipi Number: "+rs.getString("composer_Caeipi_Number"));
						System.out.println("Created by: "+rs.getInt("Created_by"));
						System.out.println("Created On: "+rs.getDate("Created_on"));
						System.out.println("Updated by: "+rs.getInt("Updated_by"));
						System.out.println("Updated On: "+rs.getDate("Updated_on"));
						break;


						case 4:
							System.out.println("Enter the Artist id :");
							int artistId=sc.nextInt();
							String selectQuery="SELECT * from artist_master where artist_id=?";
							Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
							PreparedStatement pst1=conn.prepareStatement(selectQuery);
							pst1.setInt(1, artistId);
							ResultSet rs1=pst1.executeQuery();
							rs1.next();
							System.out.println("Artist ID: "+rs1.getInt("artist_Id"));
							System.out.println("Artist Name: "+rs1.getString("artist_Name"));
							System.out.println("Artist Type: "+rs1.getString("artist_Type"));
							System.out.println("Artist Born Date: "+rs1.getString("artist_Born_Date"));
							System.out.println("Artist Died Date: "+rs1.getDate("artist_Died_Date"));
							System.out.println("Created By: "+rs1.getInt("created_By"));
							System.out.println("Created On: "+rs1.getDate("created_On"));
							System.out.println("Updated By: "+rs1.getInt("updated_By"));
							System.out.println("Updated On: "+rs1.getDate("updated_On"));
							break;

							
							
							

						case 5:  AddSongs();
						break;



						default: System.out.println("Thank you Please visit again");
						System.exit(0);   
						}

					}
				}
				break;

			case 2:
				System.out.println("************************************************************");
				System.out.println("*****************WelCome User***************");
				System.out.println("************************************************************");
				System.out.println("Please Enter Your Login Credentials");
				System.out.println("Enter USER ID : ");
				int userId=sc.nextInt();
				System.out.println("Enter USER PASSWORD : ");
				String userPWD=sc.next();
				if(medSer.validateUserId(userId))
				{
					if(medSer.validateUserPwd(userPWD))
					{
						System.out.println("Welcome you are logged in as user");
						System.out.println("Select the operation");
						System.out.println(" \n \t 1: Find Song");

						int choice=sc.nextInt();
						switch(choice)
						{
						case 1: FindSong();
						break;
						}
					}
					break;

				}
			}
		}
	}









	/*****************************************ADD COMPOSER**************************************************/
	private static void AddComposer() throws MediaException
	{
		System.out.println(" Enter the Composer Name : ");
		String composerName=sc.next();

		System.out.println(" Enter the Composer Birth Date : ");
		String composerBirthDate=sc.next();

		System.out.println("Enter the Composer Caeipi Number: ");
		String ComposerCaNo=sc.next();

		System.out.println(" Created By: ");
		int createdBy=sc.nextInt();

		System.out.println(" Updated By: ");
		int updatedBy=sc.nextInt();


		Composer_Master cm=new Composer_Master();
		cm.setComposer_Name(composerName);
		cm.setComposer_Born_Date(composerBirthDate);
		cm.setComposer_Caeipi_Number(ComposerCaNo);
		cm.setCreated_by(createdBy);
		cm.setUpdated_by(updatedBy);

		int composerAdded=medSer.addComposer(cm);

		if(composerAdded==1)
		{
			System.out.println("Composer Added successfully");
		}
		else
		{

			System.out.println("Composer couldnt be added");
		}

	}

	/*********************************************** ADD ARTIST* ***************************************************/
	private static void AddArtist() throws MediaException
	{
		System.out.println(" Enter the Artist Name : ");
		String artistName=sc.next();

		System.out.println(" Enter the Artist type : ");
		String artistType=sc.next();

		System.out.println(" Enter the Artist born date : ");
		String artistBirthDate=sc.next();

		System.out.println(" Created By: ");
		int createdBy=sc.nextInt();

		System.out.println(" Updated By: ");
		int updatedBy=sc.nextInt();


		Artist_Master am=new Artist_Master();
		am.setArtist_Name(artistName);
		am.setArtist_Type(artistType);
		am.setArtist_Born_Date(artistBirthDate);
		am.setCreated_By(createdBy);
		am.setUpdated_By(updatedBy);;

		int artistAdded=medSer.addArtist(am);

		if(artistAdded==1)
		{
			System.out.println("Artist Added successfully");
		}
		else
		{

			System.out.println("Artist couldnt be added");
		}


	}








	/***************************************************ADD SONGS* **********************************************/	

	private static void AddSongs() throws MediaException 
	{
		System.out.println(" Enter the Song Name: ");
		String songName=sc.next();

		System.out.println(" Enter the song duration: ");
		String songDuration=sc.next();

		System.out.println(" Created By: ");
		int createdBy=sc.nextInt();

		System.out.println(" Updated By: ");
		int updatedBy=sc.nextInt();


		Song_Master sm=new Song_Master();
		sm.setSong_name(songName);
		sm.setSong_duration(songDuration);
		sm.setCreated_by(createdBy);
		sm.setUpdated_by(updatedBy);

		int songAdded=medSer.addSongs(sm);

		if(songAdded==1)
		{
			System.out.println("Song Successfully Added");
		}
		else
		{

			System.out.println("Some error occured while adding song");
		}

	}

	/*************************************************** FIND SONG************************************************/
	private static void FindSong() 
	{
		Song_Master song= new Song_Master();
		System.out.println("Enter the song id: ");
		int song_id=sc.nextInt();

		if(song.getSong_name()==null)
		{
			System.out.println("Details not found. ");

		}
		else
		{
			System.out.println(song);
		}

	}



}
