package com.cg.media.dao;

import java.util.ArrayList;

import com.cg.media.bean.Artist_Master;
import com.cg.media.bean.Composer_Master;
import com.cg.media.bean.Song_Master;
import com.cg.media.exception.MediaException;



public interface MediaDao 
{

	public int addComposer(Composer_Master cm) throws MediaException;
	public int addArtist(Artist_Master am) throws MediaException;
	public Composer_Master getComposer(int composer_Id) throws MediaException;	
	public int addSongs(Song_Master sm) throws MediaException;
	public Song_Master getSong(int song_id) throws MediaException;
	ArrayList<Composer_Master> getComposerDetails (int composer_id) throws MediaException;
	public int updateComposer(int composer_id) throws MediaException;
	
	
	
	
/**********************************Generate ID****************************************/
	
	public int generateSongId() throws MediaException;
	public int generateComposerId() throws MediaException;
	public int generateArtistId() throws MediaException;
	
	
/***************************************login***********************************************/
	
public int getUserId() throws MediaException;
	
	public String getUserPwd() throws MediaException;
	
	public int getAdminId() throws MediaException;
	
	public String getAdminPwd() throws MediaException;
	
	
}
