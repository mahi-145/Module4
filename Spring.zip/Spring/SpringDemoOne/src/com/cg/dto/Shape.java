package com.cg.dto;

public interface Shape 
{
	public void getShape();
}
