package com.cg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.Employee;
//import com.cg.dto.Shape;

public class MyTest 
{
	public static void main(String[]args)
	{
		//container:ApplicationContext 
		ApplicationContext app=
				new ClassPathXmlApplicationContext("Spring.xml");
		//Shape sp=(Shape) app.getBean("tri");
		//sp.getShape();
		Employee em=(Employee) app.getBean("emp");
		em.getAllDetails();
	}
}
