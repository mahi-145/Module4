package com.cg.dto;

public class Employee
{
int empId;
String empName;
double salary;
String empBu;
int empAge;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getEmpBu() {
	return empBu;
}
public void setEmpBu(String empBu) {
	this.empBu = empBu;
}
public int getEmpAge() {
	return empAge;
}
public void setEmpAge(int empAge) {
	this.empAge = empAge;
}
public void getAllEmpDetails()
{
	System.out.println("Employee Details");
	System.out.println("____________________");
	System.out.println("Employee Id :"+empId+"\nEmployee Name: "+empName+"\nEmployee Salary:"+salary);
	System.out.println("Employee BU: "+empBu+"\nEmployee Age :"+empAge);
}

}
