package com.cg.dto;

import java.util.List;



public class Employee implements EmployeeDetail
{
 int empId;
 String empName;
List<Project>pro;



	public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public List<Project> getPro() {
	return pro;
}
public void setPro(List<Project> pro) {
	this.pro = pro;
}

	@Override
	public void getEmpDetails() 
	{
		System.out.println("Employee ID is"+empId+"\nEmployee name is "+empName);
		for(Project project:pro)
		{
			System.out.println("Project Id is"+project.getProId());
			System.out.println("Project Name is "+project.getProjName());
		}
		
	}
	
}
