package com.cg.dto;

public interface EmployeeDetail 
{
	public void getEmpDetails();
}
