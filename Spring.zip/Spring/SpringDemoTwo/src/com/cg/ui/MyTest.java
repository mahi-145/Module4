package com.cg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.EmployeeDetail;


public class MyTest {

	public static void main(String[] args) 
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("Spring.xml");
		EmployeeDetail e=(EmployeeDetail) app.getBean("emp");
		e.getEmpDetails();
	}

}
