package com.cg.spring.service;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.spring.dao.ITraineeDao;
import com.cg.spring.dto.Trainee;

@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService
{

	@Autowired
	ITraineeDao traineedao;
	@Override
	public int addTrainee(Trainee tra) 
	{
		
		return traineedao.addTrainee(tra);
	}

	@Override
	public void deleteTrainee(int traineeId) 
	{
		traineedao.deleteTrainee(traineeId);
		
	}
	
	
}
