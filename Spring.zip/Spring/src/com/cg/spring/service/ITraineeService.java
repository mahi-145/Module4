package com.cg.spring.service;

import com.cg.spring.dto.Trainee;

public interface ITraineeService 
{
	public int addTrainee(Trainee tra);
	public void deleteTrainee(int traineeId);
}
