package com.cg.spring.dao;

import com.cg.spring.dto.Trainee;

public interface ITraineeDao 
{
	public int addTrainee(Trainee tra);
	public void deleteTrainee(int traineeId);
}
