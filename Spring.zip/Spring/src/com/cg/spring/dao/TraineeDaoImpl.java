package com.cg.spring.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.spring.dto.Trainee;

@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao 
{

	@PersistenceContext
	EntityManager entitymanager;

/********************************* ADD *****************************************/
	@Override
	public int addTrainee(Trainee tra) 
	{
		entitymanager.persist(tra);
		entitymanager.flush();
		
		return tra.getTraineeId();
	}
	
	
/****************************************** Delete *****************************************/	

	@Override
	public void deleteTrainee(int traineeId) 
	{
		Query queryone=entitymanager.createQuery("DELETE from Trainee where traineeId=:id");
		queryone.setParameter("id", traineeId);
		queryone.executeUpdate();
		
	}

}
