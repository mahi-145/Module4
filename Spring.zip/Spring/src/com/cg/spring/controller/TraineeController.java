package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.dto.Trainee;
import com.cg.spring.service.ITraineeService;

@Controller
public class TraineeController
{
	@Autowired
	ITraineeService traineeservice;
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String getAll()
	{
		return "login";
	}
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String operation()
	{
		return "traineeoperations";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addTrainee(@ModelAttribute("trai") Trainee tra,Map<String,Object>model)
	{
		List<String> myDom=new ArrayList<>();
		myDom.add("Please Select");
		myDom.add("JAVA");
		myDom.add("ORACLE");
		myDom.add("VnV");
		model.put("dom", myDom);
		return "addTrainee";
		
	}
	
	@RequestMapping(value="insertData",method=RequestMethod.POST)
	public ModelAndView insertTrainee(@Valid @ModelAttribute("trai") Trainee tra,BindingResult result,Map<String,Object>model)
	{
		int id=0;
		if(result.hasErrors())
		{
			List<String> myDom=new ArrayList<>();
			myDom.add("Please Select");
			myDom.add("JAVA");
			myDom.add("ORACLE");
			myDom.add("VnV");
			model.put("dom", myDom);
			return new ModelAndView("addTrainee");
		}
		else
		{
			id=traineeservice.addTrainee(tra);
		}
		return new ModelAndView("success", "tdata", id);
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteTrainee()
	{
		return "deletetrainee";
		
	}
	
	@RequestMapping(value="dodelete",method=RequestMethod.GET)
	public String traineeDelete(@RequestParam("tid") int id)
	{
		traineeservice.deleteTrainee(id);
		return "traineeoperations";
		
	}
}
